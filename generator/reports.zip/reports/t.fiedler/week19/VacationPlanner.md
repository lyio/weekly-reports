
#####SVN Revision: r156067 
[Bug 57120](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=57120) - Probleme mit Mailversand aufgrund des asynchronen Sendens von E-Mails.

- We suspect that the mail server rejects two identical mails sent that are sent nearly simultaneously. So the vacation approved reply mails now contain the to and from dates. This will help confirming the theory and also make the mails a little bit more useful.

