
#####SVN Revision: r155831 
[Bug 55589](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=55589) - Abgrenzungsliste RAB Rechnungswesensoftware

- We decided to add an 'Excluded' flag to the Invoice table and filter accordingly at retrieval
- Write DB Update script to add the new column
- Map new column
- Add new column as filter criterion in InvoiceItemRepository
- Minor refactoring in Voucher.cs to leverage OO dynamic dispatch

#####SVN Revision: r156082 
[Bug 55589](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=55589) - Abgrenzungsliste RAB Rechnungswesensoftware

- Add UI component to exclude invoice from deferral list in VoucherDetails view (it's a button)
- Button changes caption depending on status of the invoice
- Button is only visible if the user has the required privileges (same as for canceling an invoice) and if the invoice is canceled 
- Add business logic capabilities to exclude/re-include invoices

