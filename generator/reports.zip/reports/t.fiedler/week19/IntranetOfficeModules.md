
#####SVN Revision: r155595 
[Bug 55250](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=55250) - Enhance the log information

- Added a more try-catch-block to improve logging

#####SVN Revision: r155612 
[Bug 55250](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=55250) - Enhance the log information

- Add Distinct modifier to the recipient list returned by GetRecipientsByEmailId. Now, only one memo is written per recipient and mailing.

#####SVN Revision: r155644 
[Bug 55250](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=55250) - Enhance the log information

- For deleted Subscribers that received Mailings in the past, no memo is written. There will be a log warning indicating this. For regular updates this should not be a problem.

