##r155459 | t.fiedler | 2015-04-29 16:17:50 +0200 (Wed, 29 Apr 2015) | 3 lines
Bug 57640 - Die E-Mails für Urlaubseintrag beinhalten den falschen Absender

- Removed unused class NewSession.cs
- Fixed an issue where the MailDistributor saved the sender of the mails and incorrectly used that for the next mail

----------
