
#####SVN Revision: r155566 
[Bug 57260](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=57260) - Berechtigungen auf Geschäftsbereichsebene für Rechnungen

- changed privilege check for "Kundenumsatz" and "Abgegrenzte Forderungsliste"

#####SVN Revision: r155569 
[Bug 57260](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=57260) - Berechtigungen auf Geschäftsbereichsebene für Rechnungen

- added test

#####SVN Revision: r155714 
[Bug 57260](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=57260) - Berechtigungen auf Geschäftsbereichsebene für Rechnungen

- removed "UserHasPrivilegeOnVoucher" called with voucher id in PermissionService
- reworked "UserHasPrivilegeOnVoucher" called with voucher id in PermissionTaskBase to call "UserHasPrivilegeOnVoucher" with voucher in PermissionService
- adjusted method calls
- adjusted tests

#####SVN Revision: r155801 
[Bug 57764](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=57764) - Vertragsabdeckungstab zeigt nicht alle Angebotspositionen

- added pager to ContractCoverageTab
- adjusted select method to jump to the offer/contract

#####SVN Revision: r155827 
[Bug 57771](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=57771) - Ein Benutzer mit Vertrag-Schreib-Berechtigungen soll ein vertrag von Akquise auf Ungültig setzen können

- changed privilege check for saving contracts so you can set contracts from "akquise" to "invalid" without having super privilege on contracts

#####SVN Revision: r155846 
[Bug 57763](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=57763) - Rechnung und Storno nur Schreibe-Berechtigungen zum Download anbieten

- download option in voucher search result grid now downloads invoice copy instead of the invoice itself
- visibility download button in voucher details now depends on write privilege on voucher
- added/adjusted tests

#####SVN Revision: r155857 
[Bug 57774](https://devsrv1.wohnfinder.de/bugzilla/show_bug.cgi?id=57774) - Beim Anlegen eines Provisionsanspruches soll der eingelogte User preselektiert werden

- selects logged in employee in employee drop down list instead of selecting employee in contract

